<?php 
error_reporting(E_ALL); ini_set('display_errors', 1); 
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=us-ascii">
	<meta name="viewport" content="width=device-width,initial-scale=1">

	<title>DataTables example - Bootstrap</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.css">
	<style type="text/css" class="init">
	* { margin:0px; padding:0px; }

	body { font-size: 150%; }

	</style>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.js"></script>
	</head>

<body style="padding-top: 50px;">
<div class="container">
<?php 
$id = $_REQUEST['id'];
require_once 'db_con.php';
$query = "SELECT * FROM `employee` WHERE id =".$id;
$result  =  $DBcon->prepare("$query");
$result->execute();
$row = $result->fetch();

 
?>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li ><a href="import_index.php">Import Data</a></li>
      <li class="active"><a href="data.php">View Data</a></li>
      <li><a href="logout.php">Logout</a></li>      
    </ul>
  </div>
</nav>
<form action="update.php" method="post" class="form-horizontal">
<div class="form-group">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
 <div class="form-group">
    <label class="control-label col-sm-2" for="email">Name: </label>
    <div class="col-sm-10">
    <input type="text" name="name" value="<?php echo $row['name']; ?>"><br>
    </div>
    </div>
    <div class="form-group">
    <label class="control-label col-sm-2" for="email">Father Name:</label>
    <div class="col-sm-10">
     <input type="text" name="fname" value="<?php echo $row['father_name']; ?>"><br></div>
     </div>
<div class="form-group">
    <label class="control-label col-sm-2" for="email">Address: </label>
    <div class="col-sm-10">
    <input type="text" name="address" value="<?php echo $row['address']; ?>?"><br></div>
    </div>
<div class="form-group">
    <label class="control-label col-sm-2" for="email">PanNumber: </label>
    <div class="col-sm-10">
    <input type="text" name="pannumber" value="<?php echo $row['pancard']; ?>"><br></div>
    </div>

 <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">Submit</button>
    </div>
  </div>
</form>
 
	
</div>	
	
	</body>
</html>