<?php
 error_reporting(E_ALL); ini_set('display_errors', 1); 
require_once 'db_con.php';
    $id = (int)$_POST["id"];
    $name = $_POST["name"];
    $fname= $_POST["fname"];
    $address= $_POST["address"];
    $pannumber = $_POST["pannumber"];
    $query="UPDATE employee SET name='$name',father_name = '$fname', address= '$address',pancard='$pannumber' WHERE id='$id'";

$result  =  $DBcon->prepare("$query");
$result->execute();
header('Location: data.php');
?>