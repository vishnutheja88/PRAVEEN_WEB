<?php

 $id = $_POST['id'];

 
 $id = $_GET['id'];
 
$id_arrya = explode(",",$id);
$count = count($id_arrya);
	

  $curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.pdfshift.io/v2/convert/",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(array("source" => "http://crazywebservices.com/tarun_gmr/affidivate.php?id=$id", "landscape" => false, "use_print" => false)),
    CURLOPT_HTTPHEADER => array('Content-Type:application/json'),
    CURLOPT_USERPWD => 'a0862adbcd16495abc010a882b235564'
));

$response = curl_exec($curl);
//file_put_contents('pdfhsift-documentation.pdf', $response);
$myfilename="c-form".date('m-d-Y_hia').'.pdf';
header('Content-type: application/x-download');
header('Content-Disposition: attachment; filename="'.$myfilename.'"');
header('Content-Transfer-Encoding: binary');
header('Content-Length: '.strlen($response));
set_time_limit(0);
echo $response;


exit;
?>