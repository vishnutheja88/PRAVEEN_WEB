<?php

$id = $_REQUEST['id'];
require_once 'db_con.php';
$query = "SELECT * FROM `employee` WHERE id =".$id;
$result  =  $DBcon->prepare("$query");
$result->execute();
$row = $result->fetch();
//print_r($row);
?>
<html>
<head>
<style>
body { font: 14px/1.4 Georgia, serif; }
#logo1 {
    text-align: right;
    float: right;
    position: relative;
    margin-top: 25px;
    border: none !important;
    max-width: 540px;
    max-height: 100px;
    overflow: hidden;
    background: transparent;
}
</style>
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="js/Matrix.js"></script>
<script src="js/jquery.freetrans.js"></script>
	<link rel='stylesheet' type='text/css' href='css/style.css' />
	<link rel='stylesheet' type='text/css' href='css/print.css' media="print" />
	<link rel="stylesheet" href="css/letter.css">
	<link href="https://fonts.googleapis.com/css?family=Special+Elite" rel="stylesheet">
<style>
#address4{
font-family: 'Special Elite', cursive;
background: transparent;
}
</style>
<title>Latter Id</title>
<style>
#header1 {
    height: 20px;
    width: 100%;
    margin: 35px 0;
    text-decoration: uppercase;
    padding: 8px 0px;
    border-bottom: 1px solid black;
    text-align: left;
    letter-spacing: 0px !important;
    font: bold 20px Helvetica, Sans-Serif !important;
    color: red;

}
#address12 {
    height: 20px;
    width: 100%;
    margin: 20px 0;
    text-decoration: uppercase;
    padding: 8px 0px;
    border-top: 1px solid;
    text-align: left;
    letter-spacing: 0px !important;
    font: bold 12px Helvetica, Sans-Serif !important;
    color:#696969;
}
</style>
</head>
<body>
<div id="page-wrap">



		<div id="header1"><?php echo $row['name']; ?></div>
		

 <div id="#" class="trans"><div id="logo1">
		 <div id="address4">For <?php echo $row['name']; ?><br/>
		 <span style="padding-left: 36px;">Real Estate Agent</span>
		  </div>
		</div></div>	

		 
<div id='bounds' style="height:910px"></div>		  
		
	 
		  
		



<script>
function myFunction() {
    window.print();
}
</script></td>
		</tr>
		</table>
<div id="identity">
		
            <div id="address12"><?php echo $row['address']; ?> </div>
</div>



<script>
		$(function(){
			// do a selector group
			$('.trans').freetrans({
				x: 50, 
				y: 50
			});
			
			//updating options, chainable
			$('#two').freetrans({
				x: 200, 
				y: 100, 
				angle: 45,
				'rot-origin': "50% 100%"  
			})
			.css({border: "1px solid pink"})

			var b = $('#two').freetrans('getBounds');
			console.log(b, b.xmin, b.ymax, b.center.x);

			$('#bounds').css({
				top: b.ymin,
				left: b.xmin,
				width: b.width,
				height: b.height
			})
		})
		</script>
</body>
</html>