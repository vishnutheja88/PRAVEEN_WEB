<?php
$id = $_REQUEST['id'];
require_once 'db_con.php';
$query = "SELECT * FROM `employee` WHERE id =".$id;
$result  =  $DBcon->prepare("$query");
$result->execute();
$row = $result->fetch();
//print_r($row);
?>
<html>
<head>
<style>
body { font: 14px/1.4 Georgia, serif; }
#logo1 {
    text-align: right;
    float: right;
    position: relative;
    margin-top: 25px;
    border: none !important;
    max-width: 540px;
    max-height: 100px;
    overflow: hidden;
    background: transparent !important;
}


</style>
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="js/Matrix.js"></script>
<script src="js/jquery.freetrans.js"></script>
<link rel='stylesheet' type='text/css' href='css/style.css' />
<link rel='stylesheet' type='text/css' href='css/print.css' media="print" />
<link rel="stylesheet" href="css/jquery.freetrans.css">
<link href="https://fonts.googleapis.com/css?family=Special+Elite" rel="stylesheet">
<style>
#address4{
font-family: 'Special Elite', cursive;
background: transparent;
}
 
</style>

</head>
<body>
<div id="page-wrap">



		<div id="header1"><textarea id="address1"><?php echo $row['name']; ?></textarea></div>
		<textarea id="header">RECEIPT</textarea>
		
		<div id="identity">
		
            <textarea id="address"><?php echo $row['address']; ?> </textarea>

            
		
		</div>
		
		<div style="clear:both"></div>
		
		<div id="customer">

          

            <table id="meta">
                <tr>
                    <td class="meta-head"></td>
                    <td><textarea></textarea></td>
                </tr>
                <tr>

                    <td class="meta-head"></td>
                    <td><textarea id="date"></textarea></td>
                </tr>
               

            </table>
		
		</div>
		
		<table id="items">
		
		  <tr>
		      <th>No</th>
		      <th>Mode of Payment</th>
		      <th>Chq//CC No</th>
		      <th>Date</th>
			   <th>Towards</th>
		      <th>Amount</th>
			  
		  </tr>
		    <tr>
		      <th><p>&nbsp;</p></th>
		      <th></th>
		      <th></th>
		      <th></th>
			   <th></th>
		      <th></th>
			  
		  </tr>
		  
		  </table>
		 
		 </br>
		  <table>
		  <tr>
		      <th>Plot/Flat No :<th><textarea id="address2"></textarea></th> </th>
		      
		      <th>Venture / Project<th><textarea id="address2"></textarea></th></th>
			    
		  </tr>
		  </table>
		
		   </br>
		  <table>
		  <tr>
		      <th>Amount Paid :<th><textarea id="address2"> </textarea></th> </th>
		      
		      <th>In Words<th><textarea id="address3"> </textarea></th></th>
			    
		  </tr>
		  </table> 
		  <div id='bounds'></div>
<div id="#" class="trans"><div id="logo1">
		 <div id="address4">For <?php echo $row['name']; ?> </br> <span style="padding-left: 36px;">Real Estate Agent</span>
		  </div>
		</div></div>
		  </br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br>
		  <p>&nbsp;</p> 
		  <p>&nbsp;</p>
		  <th id="address3">For </br></br></br>
		  CASHIER / ACCOUNTANT</br>
		  *Note: Cheques are subject to realisation
		  </th>
		 
		  
		



<script>
function myFunction() {
    window.print();
}
</script></td>
		</tr>
		</table>


</div>
<div class="jquery-script-clear"></div>
</div>
</div>



<script>
		$(function(){
			// do a selector group
			$('.trans').freetrans({
				x: 50, 
				y: 50
			});
			
			//updating options, chainable
			$('#two').freetrans({
				x: 200, 
				y: 100, 
				angle: 45,
				'rot-origin': "50% 100%"  
			})
			.css({border: "1px solid pink"})

			var b = $('#two').freetrans('getBounds');
			console.log(b, b.xmin, b.ymax, b.center.x);

			$('#bounds').css({
				top: b.ymin,
				left: b.xmin,
				width: b.width,
				height: b.height
			})
		})
		</script>
</body>
</html>