<?php 
error_reporting(E_ALL); ini_set('display_errors', 1); 
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=us-ascii">
	<meta name="viewport" content="width=device-width,initial-scale=1">

	<title>DataTables example - Bootstrap</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script    type="text/javascript"    src="https://code.jquery.com/jquery-3.1.1.js"></script>
	
	<style type="text/css">
	
	* { margin:0px; padding:0px; }

	body { font-size: 150%; }
table.dataTable tr th.select-checkbox.selected::after {
    content: "✔";
    margin-top: -11px;
    margin-left: -4px;
    text-align: center;
    text-shadow: rgb(176, 190, 217) 1px 1px, rgb(176, 190, 217) -1px -1px, rgb(176, 190, 217) 1px -1px, rgb(176, 190, 217) -1px 1px;
}

	</style>
	
</head>

<body style="padding-top: 50px;">
<div class="container">
<?php 
require_once 'db_con.php';
$query = "SELECT * FROM `employee` ORDER BY id DESC";
$result  =  $DBcon->prepare("$query");
$result->execute();
?>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li ><a href="import_index.php">Import Data</a></li>
      <li class="active"><a href="data.php">View Data</a></li>
      <li><a href="logout.php">Logout</a></li>      
    </ul>
  </div>
</nav>
<div class="row">
	<div class="col-md-6">

    <table id="example" class="table table-striped table-bordered display" cellspacing="0" width="100%">
					<thead>
						<tr>
							 <th><input type="checkbox" id="selectall"/></th>
							<th>Name</th>
							<th>Father Name</th>
							<th>Address</th>
							<th>Pancard</th>
							<th>Date</th>
							<th>Place</th>
							<!--<th>Affidivate no tax years</th>-->
							<th>Receipt</th>
							<th>Letter Head</th>
							<th>Affidivate Letter</th>
							<th>Action</th>
						</tr>
					</thead>

					<tbody>
						<?php  
						$i = 1;
						while($row = $result->fetchAll()) { ?>
						<?php //print_r($row); ?>
						<?php foreach ($row as $key => $value) { ?>
							
						
							<tr>
							 <td><input type="checkbox" name="id[]" class="case" value="<?php echo $value['id']; ?>"></th>
							<td><?php echo substr($value['name'], 0, 5) ; ?></td>
							<td align="center"><?php echo $value['father_name'] ; ?></td>
							<td align="center"><?php echo substr($value['address'], 0, 5) ; ?></td>
							<td><?php echo $value['pancard'] ; ?></td>
							<td><?php echo $value['date'] ; ?></td>
							<td><?php echo $value['place'] ; ?></td>
							<!--<td><?php echo $value['affidate_date'] ; ?></td>-->
							<td><a href="receipt.php?id=<?php echo $value['id'] ; ?>" target="_blank">
							
							 View 
							 
							</a> |<a href="receipt_pdf.php?id=<?php echo $value['id'] ; ?>" target="_blank"> Download</a></td>
							<td><a href="latterid.php?id=<?php echo $value['id'] ; ?>" target="_blank"> View  </a> |<a href="letterhead.php?id=<?php echo $value['id'] ; ?>" target="_blank"> Download</a> </th>
							<td><a href="affidivate.php?id=<?php echo $value['id'] ; ?>" target="_blank"> View </a> |<a href="affidivatepdf.php?id=<?php echo $value['id'] ; ?>" target="_blank"> Download</a></td>
							<td><a href="editfile.php?id=<?php echo $value['id'] ; ?>" target="_blank"> edit</a>|
							<span  class="delete_class" id="<?php echo $value['id']; ?>">Delete</span></td>
							<?php $i++;  } ?>
							<?php } ?>
							 
						</tr>
										
					</tbody>
	</table>


</div>

</div>


</div>
<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script>
 
$(document).ready(function(){

 // Delete 
 $('.delete_class').click(function(){
   // Delete id
  var el = this;
  var id = this.id;
  var splitid = id.split("_");

  // Delete id
  var deleteid = id;
 
  // AJAX Request
  $.ajax({
   url: 'delete_page.php',
   type: 'POST',
   data: { delete_id:deleteid  },
   success: function(response){

    alert('sucessfully deleted')

   }
  });

 });

}); 
 
</script>

	 
      <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
      <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
      <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript" class="init">
$(document).ready(function() {
    $('#example').DataTable();
} );
	</script>
<SCRIPT language="javascript">
$(function(){

	// add multiple select / deselect functionality
	$("#selectall").click(function () {
		  $('.case').attr('checked', this.checked);
	});

	// if all checkbox are selected, check the selectall checkbox
	// and viceversa
	$(".case").click(function(){

		if($(".case").length == $(".case:checked").length) {
			$("#selectall").attr("checked", "checked");
		} else {
			$("#selectall").removeAttr("checked");
		}

	});
});
</SCRIPT>
<script type="text/javascript"><!--
// Returns an array with values of the selected (checked) checkboxes in "frm"
function getSelectedChbox(frm) {
  var selchbox = [];        // array that will store the value of selected checkboxes

  // gets all the input tags in frm, and their number
  var inpfields = document.querySelectorAll('input[type=checkbox]:checked');
  var nr_inpfields = inpfields.length;

  // traverse the inpfields elements, and adds the value of selected (checked) checkbox in selchbox
  for(var i=0; i<nr_inpfields; i++) {
    if(inpfields[i].type == 'checkbox' && inpfields[i].checked == true) selchbox.push(inpfields[i].value);
  }

  return selchbox;
}

  /* Test this function */
// When click on #btntest, alert the selected values
document.getElementById('btntest1').onclick = function(){
  var selchb = getSelectedChbox(this.form);     // gets the array returned by getSelectedChbox()
  document.getElementById("mytext").value =selchb; 
}
document.getElementById('btntest2').onclick = function(){
  var selchb = getSelectedChbox(this.form);     // gets the array returned by getSelectedChbox()
  document.getElementById("mytext1").value =selchb; 
}
document.getElementById('btntest3').onclick = function(){
  var selchb = getSelectedChbox(this.form);     // gets the array returned by getSelectedChbox()
  document.getElementById("mytext2").value =selchb; 
}

//-->
</script>
</body>
</html>