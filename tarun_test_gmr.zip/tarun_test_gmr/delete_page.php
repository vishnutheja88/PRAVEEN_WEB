<?php
require_once 'db_con.php';
$id = $_POST['delete_id'];
$query = "DELETE FROM `employee` WHERE `id` = $id";
$result  =  $DBcon->prepare("$query");
$result->execute();
?>