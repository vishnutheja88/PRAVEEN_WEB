<?php

/*
Developer: Ehtesham Mehmood
Site:      PHPCodify.com
Script:    Import Excel to MySQL using PHP and Bootstrap
File:      import.php
*/

// Including database connections
require_once 'db_con.php';

if(isset($_POST["submit_file"]))
{
 $file = $_FILES["file"]["tmp_name"];
 $file_open = fopen($file,"r");
 $counter = 1;
 while(($csv = fgetcsv($file_open, 1000, ",")) !== false)
 {
 	if($counter !=1) {
		  $name = $csv[0];
		  $father_name = $csv[1];
		  $address = $csv[2];
		  $pancard = $csv[3];
		  $date = $csv[4];
		  $place = $csv[5];
		  $affidate_date = $csv[6];

		  $stmt = $DBcon->prepare("INSERT INTO employee(name,father_name,address,pancard,date,place,affidate_date) VALUES(:name,:father_name,:address,:pancard,:date,:place,:affidate_date)");

		  $stmt->bindparam(':name', $name);
		  $stmt->bindparam(':father_name', $father_name);
		  $stmt->bindparam(':address', $address);
		  $stmt->bindparam(':pancard', $pancard);
		  $stmt->bindparam(':date', $date);
		  $stmt->bindparam(':place', $place);
		  $stmt->bindparam(':affidate_date', $affidate_date);
		  $stmt->execute();
		  }
    $counter++;
 }
}

echo "CSV Imported Successfully";
header("location: data.php");
?>
